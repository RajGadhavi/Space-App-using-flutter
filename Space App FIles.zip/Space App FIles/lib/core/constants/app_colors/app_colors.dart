import 'package:flutter/material.dart';

class AppColors {
  static const Color appBackGroundColor = Colors.black;
  static const Color motherEarthColor =Color(0xffB6F3FF);
  static const Color marsColor=Color(0xffF6E3C4);
  static const Color uranusColor =Color(0xffDCC7FF);
}
