class AppImages {
  static const String earthSvg="assets/svgs/earth.svg";
  static const String marsSvg="assets/svgs/Mars.svg";
  static const String purplePlanetSvg="assets/svgs/purple planet.svg";
  static const String uranusSvg="assets/svgs/Uranus.svg";
  static const String venusSvg="assets/svgs/Venus.svg";
  static const String starsSvg="assets/svgs/Star 1.svg";
  static const String fadedStarSvg="assets/svgs/Star 4.svg";
  static const String saturnSvg= "assets/svgs/saturn.svg";
}